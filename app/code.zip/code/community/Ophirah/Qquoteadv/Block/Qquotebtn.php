<?php
class Ophirah_Qquoteadv_Block_Qquotebtn extends  Mage_Catalog_Block_Product_Abstract
{
    protected $product = null;
    
	public function _prepareLayout(){
    
		return parent::_prepareLayout();
    }
}