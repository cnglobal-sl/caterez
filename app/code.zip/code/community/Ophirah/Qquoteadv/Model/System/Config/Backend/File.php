<?php

class Ophirah_Qquoteadv_Model_System_Config_Backend_File extends Mage_Adminhtml_Model_System_Config_Backend_File //Mage_Core_Model_Config_Data
{
  //upload functionality for client requests  //allow files types, size file, etc

}
