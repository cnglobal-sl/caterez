<?php
class Conlabz_Mreport_Block_Adminhtml_Export extends Mage_Adminhtml_Block_Widget_Form_Container
{
  public function __construct()
  {
  	$this->setTemplate('export/order.phtml');  
  }
  
  
}


