<?php
class Conlabz_Mreport_Block_Adminhtml_Exportbread extends Mage_Adminhtml_Block_Widget_Form_Container
{
  public function __construct()
  {
  	$this->setTemplate('export/breadcount.phtml');  
  }
  
  
}


