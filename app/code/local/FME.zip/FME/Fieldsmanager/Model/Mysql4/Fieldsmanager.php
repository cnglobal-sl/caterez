<?php 

class FME_Fieldsmanager_Model_Mysql4_Fieldsmanager extends Mage_Eav_Model_Entity_Attribute
{

    
    
} 